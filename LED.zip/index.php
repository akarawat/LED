<?php
include "db_connection.php";
	if (isset($_POST["ledno"])){
		$conn = OpenCon();
		$sql = "select ledno from ledcfg where ledno = '".$_POST["ledno"]."'";
		$result = $conn->query($sql);
		//echo $sql;
		if ($result->num_rows > 0) {
		// output data of each row
			while($row = $result->fetch_assoc()) {
				//echo "id: " . $row["ledno"]."<br>";
				$_ledno = $row["ledno"];
			}
		}
	}
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Burnstudio</title>
  <link rel="stylesheet" href="style.css">

  
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.5.1/jquery.min.js"></script>
  <script src="js/slides.min.jquery.js"></script>
	
	<!--[if IE]>
	<script type="text/javascript">
	(function(){
	var html5elmeents = "address|article|aside|audio|canvas|command|datalist|details|dialog|figure|figcaption|footer|header|hgroup|keygen|mark|meter|menu|nav|progress|ruby|section|time|video".split('|');
	for(var i = 0; i < html5elmeents.length; i++){
	document.createElement(html5elmeents[i]);
	}
	}
	)();
	</script>
	<![endif]-->
</head>
<body>
	<div id="header-wrap">
		<header class="group">
			<h2><a href="index.php" title="LED Matrix By scsthai.com">LED Matrix</a></h2>
			<!--<div id="call">
				<img src="images/SCSLogo.png" width="170"/>
			</div>
            -->
            <!-- end call -->
            <form name="setled" method="post" action="#" enctype="multipart/form-data">
			<nav class="group">
				<ul>
					<li class="home"><a href="#" title="">Home</a></li>
                    <li><a href="#" title="LED NO :">ระบุหมายเลข LED</a></li>
                    <li>
						<div align="center">
							<input type="text" name="ledno" placeholder="LED NO :" />
							<input type="submit" name="search" value=" GO " class="search"/>
						</div>
                    </li>
                    <?php
					if (isset($_POST["ledno"])){
						if (isset($_ledno)){
						?>
						<li>
							<a href="#"><?php echo $_ledno;?></a>
						</li>
						<?php	
						}else{
						?>
						<li>
							<a href="#">ไม่พบหมายเลขนี้ในระบบ</a>
						</li>
						<?php
						}
					}
					?>
                    
                    <li class="last">
                        <a href="#"> </a>
					</li>
				</ul>
			</nav>
            </form>
		</header>
	</div><!-- end header wrap -->
<script>
		$(function(){
			$('#slides').slides({
				preload: true,
				generateNextPrev: true,	
			});
		});
</script>

</body>
</html>
